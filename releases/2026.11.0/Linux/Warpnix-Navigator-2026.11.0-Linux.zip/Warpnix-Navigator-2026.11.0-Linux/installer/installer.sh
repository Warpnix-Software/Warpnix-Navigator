#!/usr/bin/env bash

set -e

# Directory containing installer.sh
INSTALLER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Parent directory = Warpnix-Navigator/
SOURCE_DIR="$(cd "$INSTALLER_DIR/.." && pwd)"

if [ ! -f "$SOURCE_DIR/wn_beta.sh" ]; then
    echo "Error: Could not find Warpnix Navigator files."
    echo "Make sure the installer folder is inside the Warpnix-Navigator folder."
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "Error: Python 3 is required."
    exit 1
fi

if ! python3 -c "import gi; gi.require_version('Gtk', '3.0'); from gi.repository import Gtk" >/dev/null 2>&1; then
    echo "Error: GTK3 Python bindings are required."
    echo "On Debian/Ubuntu:"
    echo "sudo apt install python3-gi gir1.2-gtk-3.0"
    echo "On FreeBSD:"
    echo "sudo pkg install python3 py311-gobject3 gtk3 webkit2gtk41"
    echo "On OpenBSD:"
    echo "sudo pkg_add python3 py3-gobject3 gtk+3 webkitgtk41"
    echo "On NetBSD:"
    echo "pkgin install python3 py-gobject3 gtk3 webkit-gtk41"
    exit 1
fi

exec python3 "$INSTALLER_DIR/installer.py" "$SOURCE_DIR"
